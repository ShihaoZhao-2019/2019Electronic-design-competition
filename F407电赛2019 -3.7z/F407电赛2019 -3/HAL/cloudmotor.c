#include "main.h"



//��̨�����ʼ��
void angle_init(void)//����MPUλ�ø�
{
	TIM4->CCR1 = 1500;
	TIM4->CCR2 = 1500;	
}

float yaw_set;
float pitch_set;
//��̨��������趨ֵ
void angle_set_update(float yaw, float pitch)
{
	if(yaw < -0.1f || yaw > 180.1f)
		yaw = 90.0f;
	float b = 2500.0f;
	float a = -200.0f / 27.0f;
	
	yaw_set = (yaw + 45.0f) * a + b;
	pitch_set = pitch * a + b;
	TIM4->CCR1 = (uint32_t)yaw_set;
	TIM4->CCR2 = (uint32_t)pitch_set;
}

void cloud_control(float angle, float distance)
{
	
}


