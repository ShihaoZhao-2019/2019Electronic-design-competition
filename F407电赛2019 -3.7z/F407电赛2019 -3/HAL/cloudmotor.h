#ifndef __CLOUDMOTOR_H___
#define __CLOUDMOTOR_H___

#include "delay.h"




void angle_init(void);
void angle_set_update(float yaw, float pitch);
void cloud_control(float angle, float distance);

#endif
