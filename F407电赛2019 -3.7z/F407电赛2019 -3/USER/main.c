#include "main.h"

int main(void)
{
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	delay_init(168);
	BSP_Init();
	
	while(1)
	{
		

		
//		question_update(1);
//		D_A_update(100, 50);
//		show_num(100);
//		show_letter('Z744');
//		OLED_ShowChar(1, 5, 'D');
//		OLED_ShowChar(8, 5, ':');
//		OLED_ShowChar(65, 5, 'A');
//		OLED_ShowChar(72, 5, ':');
//		OLED_ShowNum(80,5,100,3,16);
//		xinxiluru_success();
//		Kyeboard();
		
//		delay_ms(2000);
//		angle_set_update(0,0);
//		delay_ms(2000);
//		angle_set_update(30,0);
//		delay_ms(2000);
//		angle_set_update(60,0);
//		delay_ms(2000);
//		angle_set_update(90,0);
//		delay_ms(2000);
//		angle_set_update(120,0);
//		delay_ms(2000);
//		angle_set_update(150,0);
//		delay_ms(2000);
//		angle_set_update(180,0);
//		delay_ms(2000);
//		angle_set_update(210,0);
//		delay_ms(2000);
//		angle_set_update(240,0);
//		delay_ms(2000);
//		angle_set_update(270,0);

//		delay_ms(2000);
//		angle_set_update(178,135);
//		delay_ms(2000);
//		angle_set_update(179,135);
//		delay_ms(2000);
//		angle_set_update(180,135);

//	delay_ms(1000);
//	TIM4->CCR1 += 1;
//	delay_ms(2000);
//	TIM4->CCR1 = 1000 *2;
//	delay_ms(2000);
//	TIM4->CCR1 = 1700 *2;
	}
}
