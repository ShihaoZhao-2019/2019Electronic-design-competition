#ifndef _CONTROL_TASK_H_
#define _CONTROL_TASK_H_

void control_task(void);

void function_1(void);
void function_2(void);
void function_3(void);
void function_4(void);
void function_5(void);
void function_6(void);



#endif
