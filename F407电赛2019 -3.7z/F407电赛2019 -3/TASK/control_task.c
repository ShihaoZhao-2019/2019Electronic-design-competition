#include "main.h"

int16_t key_set_distance = 0;
int16_t key_set_angle = 0;

uint8_t count_init_1 = 0;
uint8_t count_init_2 = 0;
uint8_t count_init_3 = 0;
uint8_t count_init_4 = 0;
uint8_t count_init_5 = 0;
uint8_t count_init_6 = 0;


void control_task() 
{
	switch(project_temp)
	{
		case 1: 	function_1();	break;
		case 2:		function_2();	break;
		case 3:		function_3();	break;
		case 4:		function_4();	break;
		case 5: 	function_5();	break;
		case 6:		function_6();	break;
	}
}

void function_1()
{
	if(count_init_1 == 0)
	{
		count_init_1 = 1;
		count_init_2 = 0;
		count_init_3 = 0;
		count_init_4 = 0;
		count_init_5 = 0;
		count_init_6 = 0;
		
		key_set_distance = 0;
		key_set_angle = 0;
		key_number_sum = 0;
	}
	else if(count_init_1 == 1)
	{
		cloud_control(0,0);
	}
}

uint8_t function_2_count = 0;

void function_2()
{
	if(count_init_2 == 0)
	{
		count_init_1 = 0;
		count_init_2 = 1;
		count_init_3 = 0;
		count_init_4 = 0;
		count_init_5 = 0;
		count_init_6 = 0;
		
		key_set_distance = 0;
		key_set_angle = 0;
		key_number_sum = 0;
	}
	else if(count_init_2 == 1)
	{
		if(function_2_count == 0)//������ֵ
		{
			OLED_Clear();
			D_A_update(key_number_sum, 0);
			question_update(project_temp);//��ʾ
			if(key_number_sure == '#')
			{
				key_number_sure = 0;
				function_2_count = 1;
				key_set_distance = key_number_sum;
				key_number_sum = 0;
			}
		}
		else if(function_2_count == 1)//ִ��
		{
			cloud_control(key_set_angle,key_set_distance);
		}
	}
	


}

uint8_t function_3_count = 0;
uint8_t function_3_distance_count = 0;

void function_3()
{
	if(count_init_3 == 0)
	{
		count_init_1 = 0;
		count_init_2 = 0;
		count_init_3 = 1;
		count_init_4 = 0;
		count_init_5 = 0;
		count_init_6 = 0;
		
		key_set_distance = 0;
		key_set_angle = 0;
		key_number_sum = 0;
	}
	else if(count_init_3 == 1)
	{
		if(function_3_count == 0)//������ֵ
		{
			if(function_3_distance_count == 0)//����D
			{
				OLED_Clear();
				D_A_update(key_number_sum, 0);
				question_update(project_temp);//��ʾ
				if(key_number_sure == '#')
				{
					key_number_sure = 0;
					function_3_distance_count = 1;
					key_set_distance = key_number_sum;
					key_number_sum = 0;
				}
			}
			else if(function_3_distance_count == 1)//����A
			{
				OLED_Clear();
				D_A_update(key_set_distance, key_number_sum);
				question_update(project_temp);//��ʾ
				if(key_number_sure == '#')
				{
					key_number_sure = 0;
					function_3_count = 1;
					key_set_angle = key_number_sum;
					key_number_sum = 0;
				}
			}
		}
		else if(function_3_count == 1)//ִ��
		{
			cloud_control(key_set_angle,key_set_distance);
		}
	}
	



}

void function_4()
{
	
}

void function_5()
{
	
}

void function_6()
{
	
}
