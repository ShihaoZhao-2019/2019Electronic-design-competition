from pyb import UART
import time


class UnionType:
    """
    模拟C语言共用体
    实现强制转换
    """
    def __init__(self):
        self.data = [0x00, 0x00, 0x00, 0x00]

    def set_int32(self, int_32):
        int_32 = int(int_32)
        self.data[0] = ((int_32 >> 24) & 0xff)
        self.data[1] = ((int_32 >> 16) & 0xff)
        self.data[2] = ((int_32 >> 8) & 0xff)
        self.data[3] = ((int_32 >> 0) & 0xff)

    def get_int32(self):
        int_32 = int(0)
        int_32 = int((self.data[0] << 24) | (self.data[1] << 16) | (self.data[2] << 8) | self.data[3])
        return int_32

    def get_str(self):
        return self.data


class Serial:
    """
    串口通信类：
    用此类创建对象后直接调用send_data(self, data_x, data_y)方法即可实现数据发送
    """
    def __init__(self):
        self.Txbuffer = [0xA5, 0xA6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
        self.pos_x = UnionType()
        self.pos_y = UnionType()
        self.uart = UART(3, 115200)
        self.uart.init(115200, bits=8, parity=None, stop=1)

    def pack_data(self, data_x, data_y):
        self.Txbuffer[2] = data_x[0]
        self.Txbuffer[3] = data_x[1]
        self.Txbuffer[4] = data_x[2]
        self.Txbuffer[5] = data_x[3]

        self.Txbuffer[6] = data_y[0]
        self.Txbuffer[7] = data_y[1]
        self.Txbuffer[8] = data_y[2]
        self.Txbuffer[9] = data_y[3]

    # 发送函数:传入两个整型
    def send_data(self, data_x, data_y):
        self.pos_x.set_int32(data_x)
        self.pos_y.set_int32(data_y)

        self.pack_data(self.pos_x.get_str(), self.pos_y.get_str())
        self.uart.write(bytearray(self.Txbuffer))
        # print(self.Txbuffer)


if __name__ == '__main__':
    # 实例化对象
    serial = Serial()
    while 1:
        # 调用方法发送数据
        serial.send_data(1920, 1080)
        time.sleep(1000)
        serial.send_data(640, 480)
        time.sleep(1000)
